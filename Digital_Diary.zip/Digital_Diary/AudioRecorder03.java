import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.sound.sampled.*;
import java.util.Date;
import java.text.SimpleDateFormat;


public class AudioRecorder03 extends JFrame{

  AudioFormat audioFormat;
  TargetDataLine targetDataLine;

  final JButton captureBtn = new JButton("Capture");
  final JButton stopBtn = new JButton("Stop");
  final JButton exitBtn = new JButton("Exit");
  final JLabel btnPanel = new JLabel(new ImageIcon(".\\images\\audio.jpg"));

  int posX=0,posY=0;
  String filename = "images//audiobg.png";


  public static void main( String args[]){
    new AudioRecorder03();
  }//end main

  public AudioRecorder03(){//constructor
      setUndecorated(true);

    captureBtn.setEnabled(true);
    stopBtn.setEnabled(false);

    //Register anonymous listeners
    captureBtn.addActionListener(
      new ActionListener(){
        public void actionPerformed(
                                  ActionEvent e){
          captureBtn.setEnabled(false);
          stopBtn.setEnabled(true);
          exitBtn.setEnabled(false);
          //Capture input data from the
          // microphone until the Stop button is
          // clicked.
          captureAudio();
        }//end actionPerformed
      }//end ActionListener
    );//end addActionListener()

    stopBtn.addActionListener(
      new ActionListener(){
        public void actionPerformed(
                                  ActionEvent e){
          captureBtn.setEnabled(true);
          stopBtn.setEnabled(false);
          exitBtn.setEnabled(true);
          //Terminate the capturing of input data
          // from the microphone.
          targetDataLine.stop();
          targetDataLine.close();
        }//end actionPerformed
      }//end ActionListener
    );//end addActionListener()

    exitBtn.addActionListener(
      new ActionListener(){
        public void actionPerformed(
                                  ActionEvent e){
           // System.exit(0);
            setVisible(false);
        }//end actionPerformed
      }//end ActionListener
    );//end addActionListener()

    //Put the buttons in the JFrame

    getContentPane().add(captureBtn);
    getContentPane().add(stopBtn);
    getContentPane().add(exitBtn);
    getContentPane().add(btnPanel);

    //Finish the GUI and make visible
    getContentPane().setLayout(new FlowLayout());
    setTitle("Audio Diary Recorder");
    this.addMouseListener(new MouseAdapter()
	{
	   public void mousePressed(MouseEvent e)
	   {
	      posX=e.getX();
	      posY=e.getY();
	      //dispose();
	   }
	});
	this.addMouseMotionListener(new MouseAdapter()
	{
	     public void mouseDragged(MouseEvent evt)
	     {
                            //sets frame position when mouse dragged
                            setLocation (evt.getXOnScreen()-posX,evt.getYOnScreen()-posY);
                            }
	});


    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setSize(300,120);
    setVisible(true);
    setResizable(false);
        Point point= new Point(500,200);
        setLocation(point);

  }//end constructor

  //This method captures audio input from a
  // microphone and saves it in an audio file.
  private void captureAudio(){
    try{
      //Get things set up for capture
      audioFormat = getAudioFormat();
      DataLine.Info dataLineInfo =
                          new DataLine.Info(
                            TargetDataLine.class,
                            audioFormat);
      targetDataLine = (TargetDataLine)
               AudioSystem.getLine(dataLineInfo);

      //Create a thread to capture the microphone
      // data into an audio file and start the
      // thread running.  It will run until the
      // Stop button is clicked.  This method
      // will return after starting the thread.
      new CaptureThread().start();
    }catch (Exception e) {
      e.printStackTrace();
      System.exit(0);
    }//end catch
  }//end captureAudio method

  //This method creates and returns an
  // AudioFormat object for a given set of format
  // parameters.  If these parameters don't work
  // well for you, try some of the other
  // allowable parameter values, which are shown
  // in comments following the declarations.
  private AudioFormat getAudioFormat(){
    float sampleRate = 8000.0F;
    //8000,11025,16000,22050,44100
    int sampleSizeInBits = 16;
    //8,16
    int channels = 1;
    //1,2
    boolean signed = true;
    //true,false
    boolean bigEndian = false;
    //true,false
    return new AudioFormat(sampleRate,
                           sampleSizeInBits,
                           channels,
                           signed,
                           bigEndian);
  }//end getAudioFormat
//=============================================//

//Inner class to capture data from microphone
// and write it to an output audio file.
class CaptureThread extends Thread{
  public void run(){
    AudioFileFormat.Type fileType = null;
    File audioFile = null;

    //Set the file type and the file extension
    // based on the selected radio button.
           Date dNow = new Date( );
           SimpleDateFormat ft = new SimpleDateFormat ("dd-MM-yyyy");
        fileType = AudioFileFormat.Type.AU;
      //audioFile = new File("junk.aif");
      audioFile= new File(".\\prog\\vocal_diary\\"+ft.format(dNow)+".au");

    try{
      targetDataLine.open(audioFormat);
      targetDataLine.start();
      AudioSystem.write(
            new AudioInputStream(targetDataLine),
            fileType,
            audioFile);
    }catch (Exception e){
      e.printStackTrace();
    }//end catch

  }//end run
}//end inner class CaptureThread
//=============================================//

}//end outer class AudioRecorder02.java
