import java.awt.*;
import javax.swing.*;
import java.io.*;
import javax.swing.border.*;
import java.awt.Rectangle;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.sql.*;
import java.text.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;

public class slideshow extends JFrame
{
    private Container myContainer;
    JButton d1,d2,d3,d4,d5,b1,delete;
     int posX=0,posY=0,id=1;
     JScrollPane scrollBarForTextArea;
      int count = 0,i=0;
    Image[] image=new Image[30];
    Image[] scaleimage=new Image[30];
    int x=0,y=0,z=0;
   ImageIcon[] icon = new ImageIcon[52];
   ImageIcon[] icon1 = new ImageIcon[52];
   JLabel pic=new JLabel();
   int sno[]=new int[50];
    PreparedStatement ps;
    Connection con ;
   int I=0;
   JLabel panel2;

     public slideshow()throws HeadlessException {
    super ("DIGITAL DIARY SLIDESHOW");

        try {
            myContainer = getContentPane();
            myContainer.setLayout(new BorderLayout());

            setSize (1370,750);
            setVisible(true);
            setResizable(true);
            Point point= new Point(0,0);
            setLocation(point);


            panel2=new JLabel(new ImageIcon(".\\images\\22.jpg"));
            panel2.setLayout(null);

            this.addMouseListener(new MouseAdapter()
            {
                public void mousePressed(MouseEvent e)
                {
                    posX=e.getX();
                    posY=e.getY();
                    //dispose();
                }
            });
            this.addMouseMotionListener(new MouseAdapter()
            {
                public void mouseDragged(MouseEvent evt)
                {
                    //sets frame position when mouse dragged
                    setLocation (evt.getXOnScreen()-posX,evt.getYOnScreen()-posY);

                }
            });

            BufferedInputStream is = null;
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");
            ps=con.prepareStatement("select * from images");
            ResultSet rs=ps.executeQuery();

            while(rs.next())
            {
                InputStream img = rs.getBinaryStream(2); // reading image as InputStream

                image[i]= ImageIO.read(img);
                sno[i]=rs.getInt(1);
                i++;
                System.out.println("true"+i);


            }

            b1= new JButton("Previous", new ImageIcon(".\\images\\fright.png"));
            b1.setBounds(5,300,100,35);
            b1.setEnabled(false);
            b1.addActionListener(new ActionListener(){

                @Override
                public void actionPerformed(ActionEvent ev){
                    setVisible(false);

                    if(z>=0){
                        icon[z]=new ImageIcon(image[z]);

                        pic.setIcon(icon[z]);
                        pic.setBounds(300,10,1100,700);
                        setVisible(true);
                        z--;
                        x=z+1;
                        panel2.add(pic);
                        I--;
                    }


                    else if(z<0)
                    {
                       JOptionPane.showMessageDialog(slideshow.this,"END OF THE SLIDESHOW ");
                        new PhotoGallery();
                    }


                    //new PhotoGallery();
                }

            });

            /*************************************/



            delete= new JButton("Delete", new ImageIcon(".\\images\\delete1.png"));
            delete.setEnabled(false);
            delete.setBounds(120,50,160,40);
            delete.addActionListener(new ActionListener(){

                @Override
                public void actionPerformed(ActionEvent ev){
//
                    try{
                    ps = con.prepareStatement("delete from images where iid=?");
                    System.out.println("x="+x+"&&&&& sno "+sno[I]);
                    ps.setInt(1,sno[I]);
                    ps.executeUpdate();
                    System.out.println("hello*****************");
                     y=x;
                    if(x<i){
                        icon[y]=new ImageIcon(image[y]);

                       // scaleimage[y] = icon[y].getImage().getScaledInstance(800,600,Image.SCALE_DEFAULT);
                        //icon1[y]=new ImageIcon(scaleimage[y]);
                        pic.setIcon(icon[y]);
                        pic.setBounds(300,10,1100,700);
                        setVisible(true);

                        ++x;
                        z=x-2;
                        panel2.add(pic);
                        I++;
                    }
                    else if(x==i)
                    {   z=x;
                     JOptionPane.showMessageDialog(slideshow.this,"END OF THE SLIDESHOW ");
                      new PhotoGallery();
                    }


                    }
                    catch(Exception e){
                    System.out.println("??????///********");
                    }

                }

            });

            panel2.add(delete);
            /************************************/

            JButton back= new JButton("Back To PhotoGallery", new ImageIcon(".\\images\\back.png"));
            back.setBounds(120,120,185,40);
            back.addActionListener(new ActionListener(){

                @Override
                public void actionPerformed(ActionEvent ev){
                    setVisible(false);
                    new PhotoGallery();
                }

            });

            panel2.add(back);

            /***********************************/

            JButton b2= new JButton("Next", new ImageIcon(".\\images\\left.png"));
            b2.setBounds(1250,300,100,35);
            b2.addActionListener(new ActionListener(){

                @Override
                public void actionPerformed(ActionEvent ev){
                    setVisible(false);
                    b1.setEnabled(true);
                    delete.setEnabled(true);
                   // x++;
                    y=x;
                    if(x<i){
                        icon[y]=new ImageIcon(image[y]);

                        pic.setIcon(icon[y]);
                        pic.setBounds(300,10,1100,700);
                        setVisible(true);

                        ++x;
                        z=x-2;
                        panel2.add(pic);
                        I++;
                    }
                    else if(x==i)
                    {   z=x;
                     JOptionPane.showMessageDialog(slideshow.this,"END OF THE SLIDESHOW ");
                      new PhotoGallery();
                    }
                }

            });

            panel2.add(b1);
            panel2.add(b2);

            setDefaultCloseOperation (EXIT_ON_CLOSE);
            myContainer.add(panel2,BorderLayout.CENTER);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(slideshow.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(slideshow.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(slideshow.class.getName()).log(Level.SEVERE, null, ex);
        }
     }

      public static void main(String[] args) {
        new slideshow();
    }
}
