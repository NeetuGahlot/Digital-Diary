Digital Diary Application

This Application is developed in java using sql as backened language and MySQL database is used to store the information.
features:
1.the use can maintain daily diary by writing it or by recording it(if you are not fond of writing).
2.the user can directly send mail from this diary without opening his account in web browser.
3.the user can maintain the photogallery.
4.the user can maintain notes and reminders.
5.the user can maintain contacts and can store all the details of the person including the picture.
6.this diary is highly secured with password. and incase user forget the password then password is sent to user's registerd email-ID so it cannot be hacked.

future scope:
1.this diary does not have recieving mail facility.
2.video recording can be incorporated to record the daily diary.