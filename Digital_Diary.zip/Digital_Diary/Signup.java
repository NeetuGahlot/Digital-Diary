import java.io.*;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

public class Signup extends JFrame
{
    private Container myContainer;
    JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8,tf9,tf10,tf11,tf12;
    JPasswordField p1, p2;
    JTextArea ta1,ta2;
    File img;
    JFileChooser chooser;
    File image;
    //JLabel label12;
    //BufferedImage img;
    String filePath;
    FileInputStream fis;
    int posX=0,posY=0;

     String pan_card;
     String organization;
     String account_no;
     String blood_group;
     String driving_licence;
     String facebook_pass;

     String special_info;

     Connection con;
     PreparedStatement ps;

    public Signup()throws HeadlessException{

        super ("DIGITAL DIARY REGISTER PAGE");
        setSize (1370,750);
        setVisible(true);
        setResizable(true);
        Point point= new Point(0,0);
        setLocation(point);


        JLabel panel=new JLabel(new ImageIcon(".\\images\\22.jpg"));

        panel.setLayout(null);


        this.addMouseListener(new MouseAdapter()
			{
			   public void mousePressed(MouseEvent e)
			   {
			      posX=e.getX();
			      posY=e.getY();
			      //dispose();
			   }
			});
			this.addMouseMotionListener(new MouseAdapter()
			{
			     public void mouseDragged(MouseEvent evt)
			     {
				setLocation (evt.getXOnScreen()-posX,evt.getYOnScreen()-posY);
			     }
			});

        setDefaultCloseOperation (EXIT_ON_CLOSE);

        myContainer = getContentPane();

        myContainer.setLayout(new BorderLayout());

        JLabel l1 = new JLabel("REGISTRATION PAGE ");
        l1.setForeground(Color.blue);
        l1.setFont(new Font("papyrus", Font.BOLD, 28));

        JLabel l2= new JLabel("enter full name* ");
        l2.setForeground(Color.blue);
        l2.setFont(new Font("papyrus", Font.BOLD, 16));
        tf1 = new JTextField(25);
        tf1.setForeground(Color.blue);
        tf1.setFont(new Font("papyrus", Font.BOLD, 16));

        JLabel l3= new JLabel("enter nick name ");
        l3.setForeground(Color.blue);
        l3.setFont(new Font("papyrus", Font.BOLD, 16));
        tf2 = new JTextField(25);

        JLabel l4= new JLabel("enter mobile no.* ");
        l4.setForeground(Color.blue);
        l4.setFont(new Font("papyrus", Font.BOLD, 16));
        tf3 = new JTextField(25);

        JLabel l5= new JLabel("enter email address* ");
        l5.setForeground(Color.blue);
        l5.setFont(new Font("papyrus", Font.BOLD, 16));
        tf4 = new JTextField(25);

        JLabel l7= new JLabel("enter diary code* ");
        l7.setForeground(Color.blue);
        l7.setFont(new Font("papyrus", Font.BOLD, 16));
        p1 = new JPasswordField(25);

        JLabel l8= new JLabel("confirm diary code* ");
        l8.setForeground(Color.blue);
        l8.setFont(new Font("papyrus", Font.BOLD, 16));
        p2 = new JPasswordField(25);

        JLabel l6= new JLabel("enter D.O.B.(1993-06-27) ");
        l6.setForeground(Color.blue);
        l6.setFont(new Font("papyrus", Font.BOLD, 14));
        tf5 = new JTextField(25);

        JLabel l9= new JLabel("enter resident address");
        l9.setForeground(Color.blue);
        l9.setFont(new Font("papyrus", Font.BOLD, 16));
        ta1 = new JTextArea("");
        ta1.setEditable(true);

        JLabel l10= new JLabel("About Yourself");
        l10.setForeground(Color.blue);
        l10.setFont(new Font("papyrus", Font.BOLD, 16));
        ta2 = new JTextArea("");

        JLabel l11= new JLabel("choose profile pic*");
        l11.setForeground(Color.blue);
        l11.setFont(new Font("papyrus", Font.BOLD, 16));
        JButton b2=new JButton("choose pic", new ImageIcon(".\\images\\d2.png"));

        JLabel l12= new JLabel("Your PAN Card No. ");
        l12.setForeground(Color.blue);
        l12.setFont(new Font("papyrus", Font.BOLD, 16));
        tf6 = new JTextField(25);

        JLabel l13= new JLabel("Your Organization ");
        l13.setForeground(Color.blue);
        l13.setFont(new Font("papyrus", Font.BOLD, 16));
        tf7 = new JTextField(25);

        JLabel l14= new JLabel("Your Account No.* ");
        l14.setForeground(Color.blue);
        l14.setFont(new Font("papyrus", Font.BOLD, 16));
        tf8 = new JTextField(25);

        JLabel l15= new JLabel("Your Blood Group ");
        l15.setForeground(Color.blue);
        l15.setFont(new Font("papyrus", Font.BOLD, 16));
        tf9 = new JTextField(25);

        JLabel l16= new JLabel("Your Driving Licence No. ");
        l16.setForeground(Color.blue);
        l16.setFont(new Font("papyrus", Font.BOLD, 16));
        tf10 = new JTextField(25);

        JLabel l17= new JLabel("Any Special Info ");
        l17.setForeground(Color.blue);
        l17.setFont(new Font("papyrus", Font.BOLD, 16));
         tf11 = new JTextField(25);

        JButton b1 = new JButton("Save data", new ImageIcon(".\\images\\e5.png"));
        JButton b3 = new JButton("Clear data", new ImageIcon(".\\images\\e6.png"));

        l1.setBounds(540, 80, 600, 30);

        l2.setBounds(300, 180, 400, 30);
        tf1.setBounds(500,180,130,30);

        l3.setBounds(300, 230, 400, 30);
        tf2.setBounds(500,230,130,30);

        l4.setBounds(300, 280, 400, 30);
        tf3.setBounds(500,280,130,30);

        l5.setBounds(300, 330, 400, 30);
        tf4.setBounds(500,330,130,30);

        l7.setBounds(300, 380, 400, 30);
        p1.setBounds(500,380,130,30);

        l8.setBounds(300, 430, 400, 30);
        p2.setBounds(500,430,130,30);

        l6.setBounds(700, 480, 400, 30);
        tf5.setBounds(900,480,130,30);

        l9.setBounds(300, 480, 400, 30);
        ta1.setBounds(500,480,130,30);

        l10.setBounds(300, 530, 400, 30);
        ta2.setBounds(500,530,130,30);

     /****************************************/

        l12.setBounds(700, 180, 400, 30);
        tf6.setBounds(900,180,130,30);

        l13.setBounds(700, 230, 400, 30);
        tf7.setBounds(900,230,130,30);

        l14.setBounds(700, 280, 400, 30);
        tf8.setBounds(900,280,130,30);

        l15.setBounds(700, 330, 400, 30);
        tf9.setBounds(900,330,130,30);

        l16.setBounds(700, 380, 400, 30);
        tf10.setBounds(900,380,130,30);

        l17.setBounds(700, 430, 400, 30);
        tf11.setBounds(900,430,130,30);


        /**********************************************/

        l11.setBounds(700, 530, 400, 30);
        b2.setBounds(900,530,160,41);

        b1.setBounds(620,620,100,35);
        b3.setBounds(750,620,100,35);

        //label12.setBounds(300, 530, 400, 30);

        panel.add(l1);
        panel.add(l2);
        panel.add(tf1);
        panel.add(l3);
        panel.add(tf2);
        panel.add(l4);
        panel.add(tf3);
        panel.add(l5);
        panel.add(tf4);
        panel.add(l6);
        panel.add(tf5);
        panel.add(l7);
        panel.add(p1);
        panel.add(l8);
        panel.add(p2);
        panel.add(l9);
        panel.add(ta1);
        panel.add(l10);
        panel.add(ta2);

        panel.add(l10);
        panel.add(tf6);
        panel.add(l12);
        panel.add(tf7);
        panel.add(l13);
        panel.add(tf8);
        panel.add(l14);
        panel.add(tf9);
        panel.add(l15);
        panel.add(tf10);
        panel.add(l16);
        panel.add(tf11);
        panel.add(l17);

        panel.add(l11);
        panel.add(b2);
        //panel.add(label12);

        panel.add(b1);
        panel.add(b3);


        b2.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                JFileChooser chooser=new JFileChooser(new File(""));

chooser.setMultiSelectionEnabled(false);
chooser.setVisible(true);

chooser.showOpenDialog(Signup.this);

    image=chooser.getSelectedFile();

}

        });


        b3.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                tf1.setText("");
                tf2.setText("");
                tf3.setText("");
                tf4.setText("");
                tf5.setText("");
                p1.setText("");
                p1.setText("");

        }
        });

        b1.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
                   int x=0;
                   String f_name=tf1.getText();
                   String n_name=tf2.getText();
                   String mobile=tf3.getText();
                   String email=tf4.getText();
                   String dob=tf5.getText();
                   char[] s1 = p1.getPassword();
                   String pass=new String(s1);

                   char[] s2 = p2.getPassword();
                   String passn=new String(s2);

                   String r_add=ta1.getText();
                   String about_y=ta2.getText();

                   pan_card=tf6.getText();
                   organization=tf7.getText();
                   account_no=tf8.getText();
                   blood_group=tf9.getText();
                   driving_licence=tf10.getText();

                   special_info=tf11.getText();

                   if((mobile.equals(""))||(email.equals(""))||(pass.equals(""))||(passn.equals(""))||(f_name.equals("")))
                       JOptionPane.showMessageDialog(Signup.this,"please fill mendatory fields");
                   else if(mobile.length()<10)
                       JOptionPane.showMessageDialog(Signup.this,"Please enter 10 digit mobile no.");

                   else
                   {
                   if(pass.equals(passn)){

	try
    {

        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        ps = con.prepareStatement("insert into user(fullname,nickname,email,pass,mobile,dob,resident_add,about_youself,image,pan_card,organization,account_no,blood_group,driving_licence,special_info) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        System.out.println("step1 done    ");

        ps.setString(1, f_name);
        ps.setString(2, n_name);
        ps.setString(3, email);
        ps.setString(4, pass);
        ps.setString(5, mobile);
        ps.setString(6, dob);
        ps.setString(7, r_add);
        ps.setString(8, about_y);

        ps.setString(10, pan_card);
        ps.setString(11, organization);
        ps.setString(12, account_no);
        ps.setString(13, blood_group);
        ps.setString(14, driving_licence);
        ps.setString(15,special_info);

        System.out.println("step 2 done    ");


        try{
         fis = new FileInputStream(image);
        ps.setBinaryStream(9, (InputStream)fis, (int)(image.length()));
            ps.executeUpdate();
            x++;
        if (x > 0)
        {
             JOptionPane.showMessageDialog(Signup.this,"Data b1d Successfully");
             setVisible(false);
             new login();
        }
        }
        catch(Exception ex){
            image = new File("E://neetu.png");
              FileInputStream inputStream = new FileInputStream(image);
              fis = new FileInputStream(image);
        ps.setBinaryStream(9, (InputStream)fis, (int)(image.length()));
        ps.executeUpdate();
        x++;
        if (x > 0)
        {
             JOptionPane.showMessageDialog(Signup.this,"Data b1d Successfully");
             setVisible(false);
             new login();
        }
        }

             JOptionPane.showMessageDialog(Signup.this,f_name+"'s Welcome To Digital Diary");
             setVisible(false);
             new Contacts();

        System.out.println("Data successfully Inserted.");



                   }
    catch(Exception ex)
    {
        System.out.println(ex);
        JOptionPane.showMessageDialog(Signup.this,"choose profile pic");
    }
                   }

                else
                    JOptionPane.showMessageDialog(Signup.this,"diary lock code is not matching");
				}
                                }

			});


        panel.add(b1);

        myContainer.add(panel,BorderLayout.CENTER);

    }

    public static void main(String[] args) {

        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        PreparedStatement ps = con.prepareStatement("select * from user");
        ResultSet rs=ps.executeQuery();
         if(rs.next())
        {
             System.out.println("already login "+rs.getString(2));
            new login();
        }

        else{
            System.out.println("please login");
            new Signup();
        }
        }
        catch(Exception ex){
             System.out.println("Check Your XAMPP ..... ");
        }

	}

}
