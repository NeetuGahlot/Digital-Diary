import java.io.*;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Toolkit;
import java.awt.event.*;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.imageio.ImageIO;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.text.SimpleDateFormat;
import java.util.Date;

public class change_pass extends JFrame
{
    private Container myContainer;
    private String f_name;
    private String n_name;
    private String email;
    private String mobile;
    private String dob;
    private String password;
    private String about_yourself;
    public JLabel panel1;
    private byte b[]=null;
    int id=1;
    PreparedStatement ps;
    JPasswordField p1,p2;
    int posX=0,posY=0;
    private JTextArea reminderArea = new JTextArea();
    Date dNow = new Date( );
    SimpleDateFormat ft;

   public void connection()
  {
       try{

        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        PreparedStatement ps = con.prepareStatement("select * from user where id=? ");
        ps.setInt(1,id);

        ResultSet rs=ps.executeQuery();

        if(rs.next())
        {
             f_name=rs.getString(2);
             about_yourself=rs.getString(9);
             b= rs.getBytes(10);
             email=rs.getString(4);
             password=rs.getString(5);
        }

        /*******************************/
        reminderArea.setText("");
        ft = new SimpleDateFormat ("dd-MM-yyyy");
        ps = con.prepareStatement("select * from reminders where reminder_date=? ");
        ps.setString(1,ft.format(dNow));

        rs=ps.executeQuery();

        while(rs.next())
        {
            reminderArea.append(rs.getString(2));
            reminderArea.append("\n\n");
            System.out.println(rs.getString(2));
        }

        /**********************************/

        ft = new SimpleDateFormat ("dd-MM");
        ps = con.prepareStatement("select * from contacts where  dob LIKE ? ");
        ps.setString(1,ft.format(dNow)+"%");

        rs=ps.executeQuery();

        while(rs.next())
        {
               String bday="wish "+rs.getString(2)+" Happy B'day";
                reminderArea.append(bday);
                reminderArea.append("\n\n");
                System.out.println(rs.getString(2));

        }

        /************************************/

        reminderArea.setEditable(false);
        /******************************/

        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }

  }


    public change_pass()throws HeadlessException{

        super ("DIGITAL DIARY SECURITY");
        connection();
        myContainer = getContentPane();
        myContainer.setLayout(new BorderLayout());
        //System.out.println("step1 done    ");
        setSize (1370,750);
        setVisible(true);
        setResizable(false);
        Point point= new Point(0,0);
        setLocation(point);

        panel1= new JLabel(new ImageIcon(".\\images\\33.jpg"));
                JLabel l3=new JLabel();

        panel1.setLayout(null);

        this.addMouseListener(new MouseAdapter()
	{
	   public void mousePressed(MouseEvent e)
	   {
	      posX=e.getX();
	      posY=e.getY();
	      //dispose();
	  }
	});
			this.addMouseMotionListener(new MouseAdapter()
			{
	     public void mouseDragged(MouseEvent evt)
	     {

                                 setLocation (evt.getXOnScreen()-posX,evt.getYOnScreen()-posY);

	     }
	});

       setDefaultCloseOperation (EXIT_ON_CLOSE);

       JLabel l1 = new JLabel("      DIGITAL DIARY SECURITY    ");
        l1.setForeground(Color.blue);
        l1.setFont(new Font("papyrus", Font.BOLD, 20));
        l1.setBounds(520,30,400,35);

        l3.setIcon(new ImageIcon (Toolkit.getDefaultToolkit().createImage(b)));
        l3.setBounds(1150,80,150,150);

        JLabel l2 = new JLabel(f_name);
         l2.setFont(new Font("Papyrus", Font.BOLD, 20));
        l2.setBounds(1150,40,120,50);

        JButton b11= new JButton("", new ImageIcon(".\\images\\homeicon.png"));
        b11.setBounds(30,130,150,40);
        b11.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new mainScreen();
        }
        });

        JButton b1= new JButton("Photo Gallery", new ImageIcon(".\\images\\photo.png"));
        b1.setBounds(30,200,150,40);
        b1.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new PhotoGallery();
        }

        });

        JButton b2= new JButton("Daily Diary", new ImageIcon(".\\images\\daily.png"));
        b2.setBounds(30,270,150,40);
        b2.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new CreateDiary();
        }

        });

        JButton b3= new JButton("Reminders", new ImageIcon(".\\images\\remin.png"));
        b3.setBounds(30,340,150,40);
        b3.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new reminder();
        }

        });
        JButton b4= new JButton("Notes", new ImageIcon(".\\images\\notes3.jpg"));
        b4.setBounds(30,410,150,40);
        b4.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new create_note();
        }

        });

        JButton b5= new JButton("Contacts", new ImageIcon(".\\images\\contacts.png"));
        b5.setBounds(30,480,150,40);
         b5.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new Contacts();
        }

        });

          JButton b6= new JButton("Profile", new ImageIcon(".\\images\\profille.png"));
        b6.setBounds(30,550,150,40);
         b6.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new profile();
        }

        });

          JButton b7= new JButton("Mailer", new ImageIcon(".\\images\\mailer.png"));
        b7.setBounds(30,620,150,40);
         b7.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new mailer();
        }

        });

        panel1.add(b7);
        panel1.add(b11);
        panel1.add(b1);
        panel1.add(b2);
        panel1.add(b3);
        panel1.add(b4);
        panel1.add(b5);
        panel1.add(b6);

        panel1.add(l1);
        panel1.add(l2);
        panel1.add(l3);
      //  panel11.add(l4);

        JScrollPane scrollBarForTextArea2=new JScrollPane(reminderArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        reminderArea.setLineWrap(true);
        scrollBarForTextArea2.setBounds(1090,250,250,400);
        reminderArea.setFont(new Font("papyrus", Font.BOLD, 18));
        reminderArea.setEditable(false);
        reminderArea.setForeground(Color.red);
        panel1.add(scrollBarForTextArea2);

        /*****************************/

        ft = new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");

        System.out.println("Current Date: " + ft.format(dNow));
        JLabel date=new JLabel(ft.format(dNow));
        date.setForeground(Color.red);
        date.setFont(new Font("papyrus", Font.BOLD, 18));
        date.setBounds(350,150,350,30);
        panel1.add(date);

        /*******************************/

        /*******************************/

       JLabel m3= new JLabel("Enter Current Password ");
        m3.setForeground(Color.blue);
        m3.setFont(new Font("papyrus", Font.BOLD, 16));
        p2 = new JPasswordField(25);
        m3.setBounds(360,250,330,50);
        p2.setBounds(700,250,160,30);

        JLabel m2= new JLabel("Enter New Password ");
        m2.setForeground(Color.blue);
        m2.setFont(new Font("papyrus", Font.BOLD, 16));
        p1 = new JPasswordField(25);

        JButton change = new JButton("change password", new ImageIcon(".\\images\\pass.png"));

        m2.setBounds(360,300,300,50);
        p1.setBounds(700,300,160,30);
        change.setBounds(800,400,170,30);

        panel1.add(m2);
        panel1.add(p1);
        panel1.add(m3);
        panel1.add(p2);
        panel1.add(change);

        change.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
                   int x=0;

                   char[] s1 = p1.getPassword();
                   String passn=new String(s1);

                   char[] s2 = p2.getPassword();
                   String passc=new String(s2);
                   if(passc.equals(password)){

        try{

        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        ps = con.prepareStatement("update user set pass=?where id=1");

        ps.setString(1,passn );
        ps.executeUpdate();

        JOptionPane.showMessageDialog(change_pass.this,"NEW PASSWORD IS SET");
        setVisible(false);
        new profile();
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
                   }
                   else{
        JOptionPane.showMessageDialog(change_pass.this,"PLEASE ENTER CORRECT CURRENT PASSWORD");

                   }

        }
	});

        panel1.add(b1);

        myContainer.add(panel1,BorderLayout.CENTER);

    }

    public static void main(String[] args) {
         new change_pass();

	}

}
