import java.io.*;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class addContact extends JFrame
{
    private Container myContainer;
    JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8;
    JLabel panel1;
    int posX=0,posY=0,id=1;
    private String f_name=new String();
    private String n_name=new String();
    private String email=new String();
    private String mobile=new String();
    private String dob=new String();
    private String about_yourself=new String();
    private JTextArea reminderArea = new JTextArea();
    Date dNow = new Date( );
    SimpleDateFormat ft;

    private byte b[]=null;
    FileInputStream fis;
    File img;
    JFileChooser chooser;
    File image;
    int pic=0;
  public void connection()
  {
       try{

        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        PreparedStatement ps = con.prepareStatement("select * from user where id=? ");
        ps.setInt(1,id);

        ResultSet rs=ps.executeQuery();

        if(rs.next())
		{
                                                                   f_name=rs.getString(2);
                                                                   n_name=rs.getString(3);
                                                                   email=rs.getString(4);
                                                                   dob=rs.getString(6);
                                                                   about_yourself=rs.getString(9);
			b= rs.getBytes(10);

        }
		else
		{
			//JOptionPane.showMessageDialog(login.this,"Sorry diary code is wrong.... try again");
		}
          /*******************************/
        reminderArea.setText("");
        ft = new SimpleDateFormat ("dd-MM-yyyy");
        ps = con.prepareStatement("select * from reminders where reminder_date=? ");
        ps.setString(1,ft.format(dNow));

        rs=ps.executeQuery();

        while(rs.next())
        {
            reminderArea.append(rs.getString(2));
            reminderArea.append("\n\n");
            System.out.println(rs.getString(2));
        }

        /**********************************/

        ft = new SimpleDateFormat ("dd-MM");
        ps = con.prepareStatement("select * from contacts where  dob LIKE ? ");
        ps.setString(1,ft.format(dNow)+"%");

        rs=ps.executeQuery();

        while(rs.next())
        {
               String bday="wish "+rs.getString(2)+" Happy B'day";
                reminderArea.append(bday);
                reminderArea.append("\n\n");
                System.out.println(rs.getString(2));

        }

        /************************************/

        reminderArea.setEditable(false);
        /******************************/

        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }


  }


  public addContact() throws HeadlessException{

        super ("DIGITAL DIARY CONTACTS");
        connection();
        myContainer = getContentPane();
        myContainer.setLayout(new BorderLayout());
        //System.out.println("step1 done    ");
        setSize (1370,750);
        setVisible(true);
        setResizable(false);
        Point point= new Point(0,0);
        setLocation(point);

        panel1= new JLabel(new ImageIcon(".\\images\\33.jpg"));
                JLabel l3=new JLabel();

        panel1.setLayout(null);

        this.addMouseListener(new MouseAdapter()
	{
	   public void mousePressed(MouseEvent e)
	   {
	      posX=e.getX();
	      posY=e.getY();
	      //dispose();
	  }
	});
			this.addMouseMotionListener(new MouseAdapter()
			{
	     public void mouseDragged(MouseEvent evt)
	     {

                                 setLocation (evt.getXOnScreen()-posX,evt.getYOnScreen()-posY);

	     }
	});

       setDefaultCloseOperation (EXIT_ON_CLOSE);

       JLabel l1 = new JLabel("      DIGITAL DIARY CONTACTS    ");
        l1.setForeground(Color.blue);
        l1.setFont(new Font("papyrus", Font.BOLD, 20));
        l1.setBounds(500,30,450,35);

        l3.setIcon(new ImageIcon (Toolkit.getDefaultToolkit().createImage(b)));
        l3.setBounds(1150,80,150,150);

        JLabel l2 = new JLabel(f_name);
         l2.setFont(new Font("Papyrus", Font.BOLD, 20));
        l2.setBounds(1150,40,120,50);

        JButton b11= new JButton("", new ImageIcon(".images\\homeicon.png"));
        b11.setBounds(30,130,150,40);
        b11.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new mainScreen();
        }
        });

        JButton b1= new JButton("Photo Gallery", new ImageIcon(".\\images\\photo.png"));
        b1.setBounds(30,200,150,40);
        b1.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new PhotoGallery();
        }

        });

        JButton b2= new JButton("Daily Diary", new ImageIcon(".\\images\\daily.png"));
        b2.setBounds(30,270,150,40);
        b2.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new CreateDiary();
        }

        });

        JButton b3= new JButton("Reminders", new ImageIcon(".\\images\\remin.png"));
        b3.setBounds(30,340,150,40);
        b3.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new reminder();
        }

        });
        JButton b4= new JButton("Notes", new ImageIcon(".\\images\\notes3.jpg"));
        b4.setBounds(30,410,150,40);
        b4.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new create_note();
        }

        });

        JButton b5= new JButton("Contacts", new ImageIcon(".\\images\\contacts.png"));
        b5.setBounds(30,480,150,40);
         b5.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new Contacts();
        }

        });

          JButton b6= new JButton("Profile", new ImageIcon(".\\images\\profille.png"));
        b6.setBounds(30,550,150,40);
         b6.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new profile();
        }

        });

         JButton b7= new JButton("Mailer", new ImageIcon(".\\images\\mailer.png"));
        b7.setBounds(30,620,150,40);
         b7.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new mailer();
        }

        });

        panel1.add(b7);

        panel1.add(b11);
        panel1.add(b1);
        panel1.add(b2);
        panel1.add(b3);
        panel1.add(b4);
        panel1.add(b5);
        panel1.add(b6);

        panel1.add(l1);
        panel1.add(l2);
        panel1.add(l3);
      //  panel1.add(l4);

        JScrollPane scrollBarForTextArea2=new JScrollPane(reminderArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        reminderArea.setLineWrap(true);
        scrollBarForTextArea2.setBounds(1090,250,250,400);
        reminderArea.setFont(new Font("papyrus", Font.BOLD, 18));
      //  reminderArea.setBackground(Color.BLACK);
        reminderArea.setForeground(Color.red);
        panel1.add(scrollBarForTextArea2);

        /*****************************/

        ft = new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");

        System.out.println("Current Date: " + ft.format(dNow));
        JLabel date=new JLabel(ft.format(dNow));
        date.setForeground(Color.red);
        date.setFont(new Font("papyrus", Font.BOLD, 18));
        date.setBounds(350, 110, 400, 30);
        panel1.add(date);

        /*******************************/

        /*******************************/

        JLabel m1 = new JLabel("Add New Contact ");
        m1.setForeground(Color.blue);
        m1.setFont(new Font("papyrus", Font.BOLD, 18));

        JLabel m2= new JLabel("enter full name* ");
        m2.setForeground(Color.blue);
        m2.setFont(new Font("papyrus", Font.BOLD, 16));
        tf1 = new JTextField(25);
        tf1.setForeground(Color.blue);
        tf1.setFont(new Font("papyrus", Font.BOLD, 16));

        JLabel m3= new JLabel("enter nick name ");
        m3.setForeground(Color.blue);
        m3.setFont(new Font("papyrus", Font.BOLD, 16));
        tf2 = new JTextField(25);
        tf2.setForeground(Color.blue);
        tf2.setFont(new Font("papyrus", Font.BOLD, 16));


        JLabel m4= new JLabel("enter mobile no. * ");
        m4.setForeground(Color.blue);
        m4.setFont(new Font("papyrus", Font.BOLD, 16));
        tf4 = new JTextField(25);
        tf4.setForeground(Color.blue);
        tf4.setFont(new Font("papyrus", Font.BOLD, 16));


        JLabel m5= new JLabel("enter email address * ");
        m5.setForeground(Color.blue);
        m5.setFont(new Font("papyrus", Font.BOLD, 16));
        tf3 = new JTextField(25);
        tf3.setForeground(Color.blue);
        tf3.setFont(new Font("papyrus", Font.BOLD, 16));

        JLabel m6= new JLabel("enter D.O.B. ");
        m6.setForeground(Color.blue);
        m6.setFont(new Font("papyrus", Font.BOLD, 16));
        tf5 = new JTextField(25);
        tf5.setForeground(Color.blue);
        tf5.setFont(new Font("papyrus", Font.BOLD, 16));

        JLabel m7= new JLabel("enter postal address");
        m7.setForeground(Color.blue);
        m7.setFont(new Font("papyrus", Font.BOLD, 16));
        tf6 = new JTextField(25);
        tf6.setForeground(Color.blue);
        tf6.setFont(new Font("papyrus", Font.BOLD, 16));

        JLabel m8= new JLabel("enter Website");
        m8.setForeground(Color.blue);
        m8.setFont(new Font("papyrus", Font.BOLD, 16));
        tf7 = new JTextField(25);
        tf7.setForeground(Color.blue);
        tf7.setFont(new Font("papyrus", Font.BOLD, 16));

        JLabel m9= new JLabel("Description");
        m9.setForeground(Color.blue);
        m9.setFont(new Font("papyrus", Font.BOLD, 16));
        tf8 = new JTextField(25);
        tf8.setForeground(Color.blue);
        tf8.setFont(new Font("papyrus", Font.BOLD, 16));

        JLabel m10= new JLabel("choose pic");
        m10.setForeground(Color.blue);
        m10.setFont(new Font("papyrus", Font.BOLD, 16));
        JButton d2=new JButton("choose pic", new ImageIcon(".\\images\\d2.png"));

        JButton d1 = new JButton("Save data", new ImageIcon(".\\images\\e5.png"));
        JButton d3 = new JButton("Clear data", new ImageIcon(".\\images\\e6.png"));

         m1.setBounds(380,150,300,30);

        m2.setBounds(400, 200, 400, 30);
        tf1.setBounds(600,200,130,30);

        m3.setBounds(400, 250, 400, 30);
        tf2.setBounds(600,250,130,30);

        m4.setBounds(400, 300, 400, 30);
        tf3.setBounds(600,300,130,30);

        m5.setBounds(400, 350, 400, 30);
        tf4.setBounds(600,350,130,30);

        m6.setBounds(400, 400, 400, 30);
        tf5.setBounds(600,400,130,30);

        m7.setBounds(400, 450, 400, 30);
        tf6.setBounds(600,450,130,30);

        m8.setBounds(400, 500, 400, 30);
        tf7.setBounds(600,500,130,30);

        m9.setBounds(400, 550, 400, 30);
        tf8.setBounds(600,550,130,30);

        m10.setBounds(400, 600, 400, 30);

        d1.setBounds(750,650,100,30);
        d3.setBounds(900,650,100,30);
        d2.setBounds(600,600,100,30);

        panel1.add(d2);
        panel1.add(d1);
        panel1.add(d3);

        panel1.add(m1);
        panel1.add(m2);
        panel1.add(tf1);
        panel1.add(m3);
        panel1.add(tf2);
        panel1.add(m4);
        panel1.add(tf3);
        panel1.add(m5);
        panel1.add(tf4);
        panel1.add(m6);
        panel1.add(tf5);
        panel1.add(m7);
        panel1.add(m8);
        panel1.add(tf6);
        panel1.add(m9);
        panel1.add(tf7);
        panel1.add(tf8);

        panel1.add(m10);

       d2.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
               chooser=new JFileChooser(new File(""));
chooser.setMultiSelectionEnabled(false);
chooser.setVisible(true);
chooser.showOpenDialog(addContact.this);
image=chooser.getSelectedFile();

System.out.println("\n file path is    "+image);
pic=1;
}

        });


        d3.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                tf1.setText("");
                tf2.setText("");
                tf3.setText("");
                tf4.setText("");
                tf5.setText("");
                tf6.setText("");
                tf7.setText("");
                tf8.setText("");

        }
        });

        d1.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){

                   String f_name=tf1.getText();
                   String n_name=tf2.getText();
                   String email=tf4.getText();
                   String mobile=tf3.getText();
                   String dob=tf5.getText();


                   String r_add=tf6.getText();
                   String website=tf7.getText();
                   String discription=tf8.getText();
                   System.out.println("*****"+email+"*****"+mobile);



          if((email.equals(""))||(mobile.equals(""))||(f_name.equals("")))
          {
                 JOptionPane.showMessageDialog(addContact.this,"please filled data marked by * ");

          }
          else{
          try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        PreparedStatement ps = con.prepareStatement("insert into contacts(fullname,nickname,email,mobile,dob,resident_add,website,discription,image) values(?,?,?,?,?,?,?,?,?)");

        System.out.println("step1 done    email "+email+"  mobile"+mobile);

        ps.setString(1, f_name);
        ps.setString(2, n_name);
        ps.setString(3, email);
        ps.setString(4, mobile);
        ps.setString(5, dob);
        ps.setString(6, r_add);
        ps.setString(7, website);
        ps.setString(8, discription);

       System.out.println("step 2 done    ");

        try{
         fis = new FileInputStream(image);
        ps.setBinaryStream(9, (InputStream)fis, (int)(image.length()));
            ps.executeUpdate();
        }
        catch(Exception e){
            image = new File("E://neetu.png");
              FileInputStream inputStream = new FileInputStream(image);
              fis = new FileInputStream(image);
        ps.setBinaryStream(9, (InputStream)fis, (int)(image.length()));
        ps.executeUpdate();
        }
System.out.println("\n file path is    "+image);
        /***************************/

        System.out.println("step 3 done    ");

        System.out.println("step 4 done    ");

             JOptionPane.showMessageDialog(addContact.this,f_name+"'s Contact is successfully added");
             setVisible(false);
             new Contacts();

        System.out.println("Data successfully Inserted.");

    }
    catch(Exception ex)
    {
        System.out.println(ex);
        System.out.println("\n catch 2   ");
         JOptionPane.showMessageDialog(addContact.this,"this "+f_name+" already exist");
    }
          }
        }
        });


/******************************************/

/*******************************************/

       //  panel.add(panel1);
        myContainer.add(panel1,BorderLayout.CENTER);

    }

    public static void main(String[] args) {
        new addContact();

	}
}
