import java.io.*;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Toolkit;
import java.awt.event.*;
import java.util.Date;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import javax.swing.ImageIcon;
import java.text.SimpleDateFormat;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import static javax.swing.JFrame.EXIT_ON_CLOSE;


public class PhotoGallery extends JFrame
{      JTextField tf2;
       String filePath=null;
        File image;
       FileInputStream img;
        JFileChooser chooser;
    private Container myContainer;
    JLabel panel1;
    int posX=0,posY=0,id=1;
    private String f_name=new String();
    private String n_name=new String();
    private String email=new String();
    private String mobile=new String();
    private String dob=new String();
    private String about_yourself=new String();
    private byte b[]=null;
    private JTextArea reminderArea = new JTextArea();
    Date dNow = new Date( );
    JButton browse,store;
    SimpleDateFormat ft;
    JTextField pic_name;

  public void connection()
  {
       try{

        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        PreparedStatement ps = con.prepareStatement("select * from user where id=? ");
        ps.setInt(1,id);

        ResultSet rs=ps.executeQuery();

        if(rs.next())
		{
                                                                   f_name=rs.getString(2);
                                                                   n_name=rs.getString(3);
                                                                   email=rs.getString(4);
                                                                   dob=rs.getString(6);
                                                                   about_yourself=rs.getString(9);
			b= rs.getBytes(10);

        }
		else
		{
			//JOptionPane.showMessageDialog(login.this,"Sorry diary code is wrong.... try again");
		}
        /*******************************/
        reminderArea.setText("");
        ft = new SimpleDateFormat ("dd-MM-yyyy");
        ps = con.prepareStatement("select * from reminders where reminder_date=? ");
        ps.setString(1,ft.format(dNow));

        rs=ps.executeQuery();
        while(rs.next())
		{
                                                                   reminderArea.append(rs.getString(2));
                                                                   reminderArea.append("\n\n");
                                                                   System.out.println(rs.getString(2));

        }
        /**********************************/

        ft = new SimpleDateFormat ("dd-MM");
        ps = con.prepareStatement("select * from contacts where  dob LIKE ? ");
        ps.setString(1,ft.format(dNow)+"%");

        rs=ps.executeQuery();

        while(rs.next())
		{
                                                                   String bday="wish "+rs.getString(2)+" Happy B'day";
                                                                   reminderArea.append(bday);
                                                                   reminderArea.append("\n\n");
                                                                   System.out.println(rs.getString(2));

        }

      reminderArea.setEditable(false);

       }
        catch(Exception ex)
        {
            System.out.println(ex);
        }


  }


  public PhotoGallery()throws HeadlessException{
  super ("DIGITAL DIARY PHOTOGALLERY");
        connection();
        myContainer = getContentPane();
        myContainer.setLayout(new BorderLayout());
        setSize (1370,750);
        setVisible(true);
        setResizable(false);
        Point point= new Point(0,0);
        setLocation(point);

        panel1= new JLabel(new ImageIcon(".\\images\\33.jpg"));
                JLabel l3=new JLabel();

        panel1.setLayout(null);

        this.addMouseListener(new MouseAdapter()
	{
	   public void mousePressed(MouseEvent e)
	   {
	      posX=e.getX();
	      posY=e.getY();
	      //dispose();
	  }
	});
			this.addMouseMotionListener(new MouseAdapter()
			{
	     public void mouseDragged(MouseEvent evt)
	     {

                                 setLocation (evt.getXOnScreen()-posX,evt.getYOnScreen()-posY);

	     }
	});

       setDefaultCloseOperation (EXIT_ON_CLOSE);

       JLabel l1 = new JLabel("      DIGITAL DIARY PHOTOGALLERY    ");
        l1.setForeground(Color.blue);
        l1.setFont(new Font("papyrus", Font.BOLD, 20));
        l1.setBounds(470,30,500,35);

        l3.setIcon(new ImageIcon (Toolkit.getDefaultToolkit().createImage(b)));
        l3.setBounds(1150,80,150,150);

        JLabel l2 = new JLabel(f_name);
         l2.setFont(new Font("Papyrus", Font.BOLD, 20));
        l2.setBounds(1150,40,120,50);

        JButton b11= new JButton("", new ImageIcon(".\\images\\homeicon.png"));
        b11.setBounds(30,130,150,40);
        b11.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new mainScreen();
        }
        });

        JButton b1= new JButton("Photo Gallery", new ImageIcon(".\\images\\photo.png"));
        b1.setBounds(30,200,150,40);
        b1.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new PhotoGallery();
        }

        });

        JButton b2= new JButton("Daily Diary", new ImageIcon(".\\images\\daily.png"));
        b2.setBounds(30,270,150,40);
        b2.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new CreateDiary();
        }

        });

        JButton b3= new JButton("Reminders", new ImageIcon(".\\images\\remin.png"));
        b3.setBounds(30,340,150,40);
        b3.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new reminder();
        }

        });
        JButton b4= new JButton("Notes", new ImageIcon(".\\images\\notes3.jpg"));
        b4.setBounds(30,410,150,40);
        b4.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new create_note();
        }

        });

        JButton b5= new JButton("Contacts", new ImageIcon(".\\images\\contacts.png"));
        b5.setBounds(30,480,150,40);
         b5.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new Contacts();
        }

        });

          JButton b6= new JButton("Profile", new ImageIcon(".\\images\\profille.png"));
        b6.setBounds(30,550,150,40);
         b6.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new profile();
        }

        });
        JButton b7= new JButton("Mailer", new ImageIcon(".\\images\\mailer.png"));
        b7.setBounds(30,620,150,40);
         b7.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new mailer();
        }

        });

        panel1.add(b7);
        panel1.add(b11);
        panel1.add(b1);
        panel1.add(b2);
        panel1.add(b3);
        panel1.add(b4);
        panel1.add(b5);
        panel1.add(b6);

        panel1.add(l1);
        panel1.add(l2);
        panel1.add(l3);

        JScrollPane scrollBarForTextArea2=new JScrollPane(reminderArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        reminderArea.setLineWrap(true);
        scrollBarForTextArea2.setBounds(1090,250,250,400);
        reminderArea.setFont(new Font("papyrus", Font.BOLD, 18));
        reminderArea.setForeground(Color.red);
        panel1.add(scrollBarForTextArea2);

        /*****************************/

        ft = new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
        JLabel date=new JLabel(ft.format(dNow));
        date.setForeground(Color.red);
        date.setFont(new Font("papyrus", Font.BOLD, 18));
        date.setBounds(350,350,300,30);
        panel1.add(date);

        /*******************************/
        /*******************************/

        JLabel p2=new JLabel("Add Photo");
        p2.setForeground(Color.blue);
        p2.setFont(new Font("papyrus", Font.BOLD, 18));
        p2.setBounds(400,420,250,30);
        panel1.add(p2);

      browse= new JButton("BROWSE", new ImageIcon(".\\images\\d2.png"));
      browse.setBounds(610,420,150,40);
      panel1.add(browse);

              browse.addActionListener(new ActionListener(){

           @Override
            public void actionPerformed(ActionEvent ev){
                JFileChooser chooser=new JFileChooser(new File(""));

                chooser.setMultiSelectionEnabled(false);
                chooser.setVisible(true);
                chooser.showOpenDialog(PhotoGallery.this);
                image=chooser.getSelectedFile();
                pic_name = new JTextField(30);
                store.setEnabled(true);

    }
});
       JLabel p3=new JLabel("Store Images");
        p3.setForeground(Color.blue);
        p3.setFont(new Font("papyrus", Font.BOLD, 16));
        p3.setBounds(400,500,250,30);

         store= new JButton("STORE", new ImageIcon(".\\images\\d3.png"));
             store.setBounds(610,500,150,40);
         panel1.add(store);
         store.setEnabled(false);

         store.addActionListener(new ActionListener(){

            @Override
        public void actionPerformed(ActionEvent ev){
        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        PreparedStatement ps = con.prepareStatement("insert into images(image) values(?)");
        img = new FileInputStream(image);
        ps.setBinaryStream(1, (InputStream)img, (int)(image.length()));
        ps.executeUpdate();
             JOptionPane.showMessageDialog(PhotoGallery.this,image+" is successfully added to the PhotoGallery");
             setVisible(false);
             new PhotoGallery();
}
    catch(Exception ex)
    {
         JOptionPane.showMessageDialog(PhotoGallery.this,"choose pic");
    }
          }

        });


ImageIcon icon = new ImageIcon(".\\images\\pht.jpg");
JLabel label = new JLabel(icon);
label.setBounds(345,00,650,400);
panel1.add(label);

          JLabel p4=new JLabel("Show Slideshow");
        p4.setForeground(Color.blue);
        p4.setFont(new Font("papyrus", Font.BOLD, 16));
        p4.setBounds(400,590,250,30);
        panel1.add(p4);

         JButton show= new JButton("SHOWGALLERY", new ImageIcon(".\\images\\D4.png"));
        show.setBounds(610,590,150,40);

           show.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
           new slideshow();
            }
        });
           panel1.add(show);
           myContainer.add(panel1,BorderLayout.CENTER);

  }
    public static void main(String[] args) {
        new PhotoGallery();

	}
}
