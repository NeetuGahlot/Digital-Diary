import java.io.*;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Toolkit;
import java.awt.event.*;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.imageio.ImageIO;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

public class forgetPass extends JFrame
{
    private Container myContainer;
    private String f_name;
    private String n_name;
    private String email;
    private String mobile;
    private String dob;
    private String about_yourself,pass;
    public JLabel panel;
    private byte b[]=null;
    int id=1;
    PreparedStatement ps;
    JPasswordField p1;
    int posX=0,posY=0;

   public void connection()
  {
       try{

        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        PreparedStatement ps = con.prepareStatement("select * from user where id=? ");
        ps.setInt(1,id);

        ResultSet rs=ps.executeQuery();

        if(rs.next())
	{
                                 f_name=rs.getString(2);
                                 about_yourself=rs.getString(9);
                                 b= rs.getBytes(10);
                                 email=rs.getString(4);
                                 pass=rs.getString(5);
        }
        else
        {

        }


        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }

  }


    public forgetPass()throws HeadlessException{

        super ("GET NEW PASSWORD");

        connection();
        myContainer = getContentPane();
        myContainer.setLayout(new BorderLayout());
        //setUndecorated(true);
        panel= new JLabel(new ImageIcon(".\\images\\forgetbg.jpg"));

        setSize (548,300);
        setVisible(true);
        setResizable(true);
        Point point= new Point(400,0);
        setLocation(point);

        this.addMouseListener(new MouseAdapter()
			{
			   public void mousePressed(MouseEvent e)
			   {
			      posX=e.getX();
			      posY=e.getY();
			      //dispose();
			   }
			});
			this.addMouseMotionListener(new MouseAdapter()
			{
			     public void mouseDragged(MouseEvent evt)
			     {
					//sets frame position when mouse dragged
					setLocation (evt.getXOnScreen()-posX,evt.getYOnScreen()-posY);

			     }
			});

        setDefaultCloseOperation (EXIT_ON_CLOSE);

       panel.setLayout(null);


        JButton b1 = new JButton("Send new password", new ImageIcon(".\\images\\sendpass.png"));

        b1.setBounds(165,90,170,40);


        b1.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
                   int x=0;

            /// in forgot password case ... we send the current password to user's registered email id
            /// from his registered email id ... use can get the current password

                   String passc=pass;
                   if(passc.equals(""))         /// from his registered email id ... use can get the current password
                       JOptionPane.showMessageDialog(forgetPass.this,"Please Enter Valid Password And Make Your Diary Secure");
                   else{
        try{

        new EmailUtil(passc,email);

        JOptionPane.showMessageDialog(forgetPass.this,"PASSWORD IS SENT TO YOUR REGISTERED EMAIL ADDRESS");
        setVisible(false);
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
                   }
        }
	});

        panel.add(b1);

        myContainer.add(panel,BorderLayout.CENTER);

    }

    public static void main(String[] args) {
         new forgetPass();

	}

}
