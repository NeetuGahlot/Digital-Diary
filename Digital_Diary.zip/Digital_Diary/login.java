import java.io.*;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Toolkit;
import java.awt.event.*;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.imageio.ImageIO;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

public class login extends JFrame
{
    private Container myContainer;
    private String f_name;
    private String n_name;
    private String email;
    private String mobile;
    private String dob;
    private String about_yourself;
    public JLabel panel;
    private byte b[]=null;
    int id=1;
    PreparedStatement ps;
    JPasswordField p1;
    int posX=0,posY=0;

   public void connection()
  {
       try{

        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        PreparedStatement ps = con.prepareStatement("select * from user where id=? ");
        ps.setInt(1,id);

        ResultSet rs=ps.executeQuery();

        if(rs.next())
        {
                                 f_name=rs.getString(2);
                                 about_yourself=rs.getString(9);
                                 b= rs.getBytes(10);

        }

        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }

  }


    public login()throws HeadlessException{

        super ("DIGITAL DIARY LOGIN");

        connection();
        myContainer = getContentPane();
        myContainer.setLayout(new BorderLayout());
        panel=new JLabel(new ImageIcon(".\\images\\22.jpg"));
        setSize (1370,750);
        setVisible(true);
        setResizable(true);
        Point point= new Point(0,0);
        setLocation(point);

        this.addMouseListener(new MouseAdapter()
			{
			   public void mousePressed(MouseEvent e)
			   {
			      posX=e.getX();
			      posY=e.getY();
			      //dispose();
			   }
			});
			this.addMouseMotionListener(new MouseAdapter()
			{
			     public void mouseDragged(MouseEvent evt)
			     {
					//sets frame position when mouse dragged
					setLocation (evt.getXOnScreen()-posX,evt.getYOnScreen()-posY);

			     }
			});

        setDefaultCloseOperation (EXIT_ON_CLOSE);

       panel.setLayout(null);

        JLabel l2= new JLabel("ENTER DIARY UNLOCK CODE ");
        l2.setForeground(Color.blue);
        l2.setFont(new Font("Papyrus", Font.BOLD, 23));
        p1 = new JPasswordField(25);

        JLabel m3=new JLabel();
        BufferedImage img = null;
        m3.setIcon((new ImageIcon(Toolkit.getDefaultToolkit().createImage(b)))) ;
        m3.setBounds(590,150,250,250);
        panel.add(m3);

        JLabel m2 = new JLabel(f_name);
        m2.setForeground(Color.white);
        m2.setFont(new Font("Papyrus", Font.BOLD, 20));
        m2.setBounds(600,370,150,50);
        panel.add(m2);

        JButton b1 = new JButton("LOGIN", new ImageIcon(".\\images\\login.jpg"));

        l2.setBounds(480,100,500,50);
        p1.setBounds(590,430,135,40);
        b1.setBounds(620,500,123,43);

        JButton forget_pass = new JButton("Forget Password", new ImageIcon(".\\images\\forget.jpg"));
        forget_pass.setBounds(565,550,198,40);
        forget_pass.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                //setVisible(false);
                new forgetPass();
        }

        });
        panel.add(forget_pass);

        panel.add(l2);
        panel.add(p1);
        panel.add(b1);

        b1.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
                   int x=0;

                   char[] s1 = p1.getPassword();
                   String passc=new String(s1);

        try{

        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        PreparedStatement ps = con.prepareStatement("select * from user where pass=? ");
        ps.setString(1,passc);

        ResultSet rs=ps.executeQuery();

        if(rs.next())
		{   n_name=rs.getString(3);
			String pass=rs.getString(5);
			b= rs.getBytes(10);
                                                                   setVisible(false);
			new mainScreen();

        }
		else
		{
			JOptionPane.showMessageDialog(login.this,"Sorry diary code is wrong.... try again");
		}
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }

        }
			});
        b1.setSize(80,30);
        panel.add(b1);

        myContainer.add(panel,BorderLayout.CENTER);

    }

    public static void main(String[] args) {
         login l=new login();

	}

}
