import java.io.*;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFileChooser;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

public class editNote extends JFrame
{
    private Container myContainer;
    JTextField t1,t2;
    JLabel panel1;
    int posX=0,posY=0,id=1,j=0;
    private String f_name=new String();
    private String n_name=new String();
    private String email=new String();
    private String mobile=new String();
    private String dob=new String();
    private String about_yourself=new String();
    private JTextArea reminderArea = new JTextArea();
    Date dNow = new Date( );
    SimpleDateFormat ft;
    private byte b[]=null;
    int current_id;
    FileInputStream fis;
    File img;
    JFileChooser chooser;
    File image;
    int pic=0;
    PreparedStatement ps;
    ResultSet rs;

    /************************/
    int sno[]=new int[10];
    /***********************/

           JTextField[] tf1=new JTextField[10];
           JTextField[] tf2=new JTextField[10];
           JTextField[] tf3=new JTextField[10];
           String[] r_note=new String[10];
           String[] r_date=new String[10];
           int[] r_id=new int[10];
           JLabel[] m=new JLabel[10];

    /****************************/

  public void connection()
  {
       try{

        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");
        int id=1;
        ps = con.prepareStatement("select * from user where id=? ");
        ps.setInt(1,id);

        rs=ps.executeQuery();


            if(rs.next())
            {
               f_name=rs.getString(2);
               n_name=rs.getString(3);
               email=rs.getString(4);
               dob=rs.getString(6);
               about_yourself=rs.getString(9);
               b= rs.getBytes(10);

            }
            else
            {

            }

         /*******************************/
        reminderArea.setText("");
        ft = new SimpleDateFormat ("dd-MM-yyyy");
        ps = con.prepareStatement("select * from reminders where reminder_date=? ");
        ps.setString(1,ft.format(dNow));

        rs=ps.executeQuery();

        while(rs.next())
        {
            reminderArea.append(rs.getString(2));
            reminderArea.append("\n\n");
            System.out.println(rs.getString(2));
        }

        /**********************************/

        ft = new SimpleDateFormat ("dd-MM");
        ps = con.prepareStatement("select * from contacts where  dob LIKE ? ");
        ps.setString(1,ft.format(dNow)+"%");

        rs=ps.executeQuery();

        while(rs.next())
        {
                String bday="wish "+rs.getString(2)+" Happy B'day";
                reminderArea.append(bday);
                reminderArea.append("\n\n");

        }

        /************************************/

        reminderArea.setEditable(false);

        /******************************/

        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
  }

  public editNote() throws HeadlessException{

super ("DIGITAL DIARY HOME");
        connection();
        myContainer = getContentPane();
        myContainer.setLayout(new BorderLayout());
        //System.out.println("step1 done    ");
        setSize (1370,750);
        setVisible(true);
        setResizable(false);
        Point point= new Point(0,0);
        setLocation(point);

        panel1= new JLabel(new ImageIcon(".\\images\\33.jpg"));
                JLabel l3=new JLabel();

        panel1.setLayout(null);

        this.addMouseListener(new MouseAdapter()
	{
	   public void mousePressed(MouseEvent e)
	   {
	      posX=e.getX();
	      posY=e.getY();
	      //dispose();
	  }
	});
			this.addMouseMotionListener(new MouseAdapter()
			{
	     public void mouseDragged(MouseEvent evt)
	     {

                                 setLocation (evt.getXOnScreen()-posX,evt.getYOnScreen()-posY);

	     }
	});

       setDefaultCloseOperation (EXIT_ON_CLOSE);

       JLabel l1 = new JLabel("      DIGITAL DIARY HOME    ");
        l1.setForeground(Color.blue);
        l1.setFont(new Font("papyrus", Font.BOLD, 20));
        l1.setBounds(550,30,400,35);

        l3.setIcon(new ImageIcon (Toolkit.getDefaultToolkit().createImage(b)));
        l3.setBounds(1150,80,150,150);

        JLabel l2 = new JLabel(f_name);
         l2.setFont(new Font("Papyrus", Font.BOLD, 20));
        l2.setBounds(1150,40,120,50);

        JButton b11= new JButton("", new ImageIcon(".\\images\\homeicon.png"));
        b11.setBounds(30,130,150,40);
        b11.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new mainScreen();
        }
        });

        JButton b1= new JButton("Photo Gallery", new ImageIcon(".\\images\\photo.png"));
        b1.setBounds(30,200,150,40);
        b1.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new PhotoGallery();
        }

        });

        JButton b2= new JButton("Daily Diary", new ImageIcon(".\\images\\daily.png"));
        b2.setBounds(30,270,150,40);
        b2.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new CreateDiary();
        }

        });

        JButton b3= new JButton("Reminders", new ImageIcon(".\\images\\remin.png"));
        b3.setBounds(30,340,150,40);
        b3.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new reminder();
        }

        });
        JButton b4= new JButton("Notes", new ImageIcon(".\\images\\notes3.jpg"));
        b4.setBounds(30,410,150,40);
        b4.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new create_note();
        }

        });

        JButton b5= new JButton("Contacts", new ImageIcon(".\\images\\contacts.png"));
        b5.setBounds(30,480,150,40);
         b5.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new Contacts();
        }

        });

          JButton b6= new JButton("Profile", new ImageIcon(".\\images\\profille.png"));
        b6.setBounds(30,550,150,40);
         b6.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new profile();
        }

        });

          JButton b7= new JButton("Mailer", new ImageIcon(".\\images\\mailer.png"));
        b7.setBounds(30,620,150,40);
         b7.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                setVisible(false);
                new mailer();
        }

        });

        panel1.add(b7);
        panel1.add(b11);
        panel1.add(b1);
        panel1.add(b2);
        panel1.add(b3);
        panel1.add(b4);
        panel1.add(b5);
        panel1.add(b6);

        panel1.add(l1);
        panel1.add(l2);
        panel1.add(l3);
      //  panel1.add(l4);

        JScrollPane scrollBarForTextArea2=new JScrollPane(reminderArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        reminderArea.setLineWrap(true);
        scrollBarForTextArea2.setBounds(1090,250,250,400);
        reminderArea.setFont(new Font("papyrus", Font.BOLD, 18));
        reminderArea.setForeground(Color.red);
        panel1.add(scrollBarForTextArea2);

        /*****************************/

        ft = new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");

        System.out.println("Current Date: " + ft.format(dNow));
        JLabel date=new JLabel(ft.format(dNow));
        date.setForeground(Color.red);
        date.setFont(new Font("papyrus", Font.BOLD, 18));
        date.setBounds(350,150,350,30);
        panel1.add(date);

        /*******************************/

        /*******************************/
         try{

            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");
            ps = con.prepareStatement("select * from notes ");

            ResultSet rs=ps.executeQuery();
            int i=1;
            while(rs.next())
	{

                   r_id[i]=rs.getInt(1);
                   r_note[i]=rs.getString(3);
                   r_date[i]=rs.getString(4);
                   i++;
        }
        /******************************/
         JLabel m2= new JLabel("ID                                        Note                                  Message");
         m2.setBounds(400,200,700,30);
        m2.setFont(new Font("papyrus", Font.BOLD, 18));
        m2.setForeground(Color.blue);
        panel1.add(m2);
        int y=0;

        for( j=1;j<i;j++){

        sno[j]=r_id[j];
        String r_idd=Integer.toString(j);
        tf1[j] = new JTextField(25);
        tf1[j].setText(r_idd);
        tf1[j].setBounds(400,250+y,50,30);
        tf1[j].setFont(new Font("papyrus", Font.BOLD, 16));
        tf1[j].setForeground(Color.blue);
        panel1.add(tf1[j]);
        tf1[j].setEnabled(false);

        tf2[j] = new JTextField(25);
        tf2[j].setText(r_note[j]);
        tf2[j].setBounds(460,250+y,300,30);
        tf2[j].setFont(new Font("Serif", Font.BOLD, 16));
        tf2[j].setForeground(Color.blue);
        panel1.add(tf2[j]);

        tf3[j] = new JTextField(25);
        tf3[j].setText(r_date[j]);
        tf3[j].setBounds(790,250+y,100,30);
        tf3[j].setFont(new Font("Serif", Font.BOLD, 16));
        tf3[j].setForeground(Color.blue);
        panel1.add(tf3[j]);

        y+=35;
        }
        /*******************************/

        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }

        /***************************************/
        /***************************************/

         JLabel m2=new JLabel("Enter the id no. which you want to Edit");
        m2.setBounds(400, 630, 300, 30);
        m2.setFont(new Font("Serif", Font.BOLD, 16));
        m2.setForeground(Color.blue);
        panel1.add(m2);

        t1=new JTextField(5);
        t1.setBounds(700, 630, 30, 30);
        t1.setFont(new Font("papyrus", Font.BOLD, 16));
        t1.setForeground(Color.red);
        panel1.add(t1);

        JButton update=new JButton("Update", new ImageIcon(".\\images\\update.png"));
        update.setBounds(850, 630, 80, 30);
        panel1.add(update);
        update.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                 if(t1.getText().equals(""))
                     JOptionPane.showMessageDialog(editNote.this,"please set valid id");
                 else
                   update(Integer.parseInt(t1.getText()));
            }

        });


        JLabel m3=new JLabel("Enter the id no. which you want to delete");
        m3.setBounds(400, 670, 300, 30);
        m3.setFont(new Font("Serif", Font.BOLD, 16));
        m3.setForeground(Color.blue);
        panel1.add(m3);

        t2=new JTextField(5);
        t2.setBounds(700, 670, 30, 30);
        t2.setFont(new Font("papyrus", Font.BOLD, 16));
        t2.setForeground(Color.red);
        panel1.add(t2);

        JButton delete=new JButton("delete", new ImageIcon(".\\images\\delete.png"));
        delete.setBounds(850, 670, 80, 30);
        panel1.add(delete);
        delete.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ev){
                 if(t2.getText().equals(""))
                     JOptionPane.showMessageDialog(editNote.this,"please set valid id");
                else
                   delete(Integer.parseInt(t2.getText()));
            }

        });

        /***************************/
        /***************************/

        myContainer.add(panel1,BorderLayout.CENTER);
    }

public void update(int id)
  {
           System.out.println("id is "+id);

           String r_note=tf2[id].getText();
           String r_date=tf3[id].getText();
           System.out.println("r_note is "+r_note);

           if((r_note.equals("")))
                       JOptionPane.showMessageDialog(editNote.this,"please fill mendatory fields");
           else{
                try{
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");
                    ps = con.prepareStatement("update notes set note=?, special_message=? where id_notes=?");

                    ps.setString(1, r_note);
                    ps.setString(2, r_date);
                    ps.setInt(3, sno[id]);

                    ps.executeUpdate();

                    JOptionPane.showMessageDialog(editNote.this,"Your Note is Successfully Updated");
                    setVisible(false);
                    new editNote();

                }
            catch(Exception ex)
            {
                     JOptionPane.showMessageDialog(editNote.this,"please set valid id");
            }
         }
  }

  public void delete(int id)
  {
      try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minorproject","root","");

        ps = con.prepareStatement("delete from notes where id_notes=?");
        ps.setInt(1,sno[id]);
        ps.executeUpdate();
        JOptionPane.showMessageDialog(editNote.this,"Your Note is Successfully Deleted");
             setVisible(false);
             new editNote();
    }
    catch(Exception ex)
    {
                     JOptionPane.showMessageDialog(editNote.this,"please set valid id");
    }

  }

}
